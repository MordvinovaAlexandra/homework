'''Дан текстовый файл. Найти и заменить в нем заданное слово. Что искать и на что заменять определяется 
пользователем.'''
# import os
# import sys
# import fileinput

with open('6text.txt', 'r', encoding = 'utf-8') as f1:
    text=f1.read()
    text = text.replace('что', 'КОТ')
# print(text)
    with open('6text1.txt', 'w', encoding = 'utf-8') as f2:
        f2.write(text)

        # while ch:= f1.read(5):
        #     if ch == 'что':
        #         f2.write('КОТ')
        #     elif ch == 'КОТ':
        #         f2.write('что')
        #     else:
        #         f2.write(ch)